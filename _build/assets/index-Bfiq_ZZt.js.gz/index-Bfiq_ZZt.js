import{g as c,k as r,i as o,c as s,t as f}from"./web-Btggxc92.js";import{M as g}from"./markdown-DfzxaKvK.js";import{s as d}from"./v8-D95HWaCp.js";import{I as h}from"./items-DvJ1tBUm.js";import"./property-BqnCpERi.js";import"./components-BqRe3wZe.js";import"./subtitle-oIDeCC3O.js";var $=f("<div><!$><!/><!$><!/>");function k(){const i=`# Root
Root level properties of a MapLibre style specify the map's layers, tile sources and other resources, and default values for the initial camera position when not specified elsewhere.


\`\`\`json
{
    "version": 8,
    "name": "MapLibre Demo Tiles",
    "sprite": "https://demotiles.maplibre.org/styles/osm-bright-gl-style/sprite",
    "glyphs": "https://demotiles.maplibre.org/font/{fontstack}/{range}.pbf",
    "sources": {... },
    "layers": [...]
}
\`\`\`

`;return(()=>{var e=c($),a=e.firstChild,[t,l]=r(a.nextSibling),n=t.nextSibling,[p,m]=r(n.nextSibling);return o(e,s(g,{content:i}),t,l),o(e,s(h,{headingLevel:"2",get entry(){return d.$root}}),p,m),e})()}export{k as default};
